package main

import (
	"template/config"
	"template/middleware"
	"template/router"

	"github.com/gin-gonic/gin"
)

func main() {
	gin.SetMode(config.Config.AppMode)
	r := gin.Default()

	config.InitSession(r)

	r.Use(middleware.Error)
	router.InitRouter(r)

	r.Run(":8088")
}
